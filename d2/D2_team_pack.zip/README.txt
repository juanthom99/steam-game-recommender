D2 team pack

Dashboard (live): https://juanthom99--steamrec-d2-dashboard-run.us-east.modal.run

DATA_NOTE.docx = draft write-up (edit this)
eda/figures = the 5 plots
clean/data_dictionary.* = data dictionary
clean/cleaning_report.md = every cleaning rule and rows affected
clean/audit_report.md = automated quality checks
eval/PROTOCOL.md = frozen evaluation rules incl. test split
split_manifest.json = test/validation counts + checksums
facts.json = key numbers quoted in the note
